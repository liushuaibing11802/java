package ninth;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Math {
	public static void main(String[] args) throws Exception {
		System.out.println("������������");
		Scanner scan=new Scanner(System.in);
		String name=scan.nextLine();
		ArrayList<String> listQues=new ArrayList<String>();
		ArrayList<Integer> listAnswer=new ArrayList<Integer>();
		int choose=menu();
		while(choose!=5) {
			switch(choose) {
			case 1:chuTi(listQues,listAnswer);break;
			case 2:does(listQues,listAnswer,name);break;
			case 3:display(listQues,listAnswer,name);break;
			case 4:sort();break;
			default:System.out.println("invalid choice");
			}
			choose=menu();
		}
		System.out.println("��лʹ��");
	}
	public static int menu() {
		System.out.println("�������������ϵͳ");
		System.out.println("1.����");
		System.out.println("2.����");
		System.out.println("3.�鿴�ɼ�");
		System.out.println("4.���а�");
		System.out.println("5.�˳�");
		System.out.println("��ѡ��(1-5)��");
		int choose;
		Scanner scan=new Scanner(System.in);
		choose=scan.nextInt();
		return choose;
	}
	public static void chuTi(ArrayList<String> listQues,ArrayList<Integer> listAnswer) {
		System.out.println("��������Ŀ������");
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
	//	ArrayList<String> listQues=new ArrayList<String>();
	//	ArrayList<Integer> listAnswer=new ArrayList<Integer>();
		String operator[]= {"+","-","*","/"};
		Random random=new Random();
		int s,n1,n2;
		int answer=0;
		for(int i=0;i<num;i++) {
			s=random.nextInt(4);
			n1=random.nextInt(100);
			n2=random.nextInt(100);
			switch(operator[s]) {
			case "+":answer=n1+n2;
				break;
			case "-":answer=n1-n2;
				break;
			case "*":answer=n1*n2;
				break;
			case "/":answer=n1/n2;
				break;
			}
			String question=n1+operator[s]+n2;
			listQues.add(question);
			listAnswer.add(answer);
		}
		System.out.println("��Ŀ���ɳɹ�");
	}
	public static void does(ArrayList<String> listQues,ArrayList<Integer> listAnswer,String name) throws Exception {
		ArrayList<String> line=new ArrayList<String>();
		int result=0;
		for(int i=0;i<listQues.size();i++) {
			System.out.println(listQues.get(i)+"=?");
			System.out.println("��������Ĵ𰸣�");
			Scanner scan=new Scanner(System.in);
			Integer r=scan.nextInt();
			String ques=listQues.get(i)+"="+r;
			listQues.set(i, ques);
			if(r-listAnswer.get(i)==0) {
				result++;
				System.out.println("��ȷ");
			}else {
				System.out.println("����");
			}
		}
		double grade=(double)result/listQues.size()*100;
		DecimalFormat df=new DecimalFormat("0.0");
		String Grade=df.format(grade);
		listQues.add(Grade);
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-hh:mm");
		String time = sdf.format(now);
		File file=new File("D:\\qq�ļ�\\eclipse-java-2019-12-R-win32-x86_64\\javaIO\\output\\result.txt");
		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file,true),"UTF-8"));
		bw.write(name+"\t"+Grade+"\t"+time+"\n");
		bw.close();
		System.out.println("�������");
	}
	public static void display(ArrayList<String> listQues,ArrayList<Integer> listAnswer,String name) {
		for(int i=0;i<listQues.size()-1;i++) {
			System.out.println("�ҵĴ𰸣�"+listQues.get(i)+"����ȷ�𰸣�"+listAnswer.get(i));
		}
		int j=listQues.size()-1;
		String grade=listQues.get(j);
		System.out.println(name+"ͬѧ��ã��ôβ���ɼ�Ϊ"+grade+"����ȷ��Ϊ"+grade+"%");
	}
	public static void sort() throws Exception {
		ArrayList<Student> listStu=new ArrayList<Student>();
		File file=new File("D:\\qq�ļ�\\eclipse-java-2019-12-R-win32-x86_64\\javaIO\\output\\result.txt");
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(file),"UTF-8"));
		String line="";
		while((line=br.readLine())!=null) {
			String[] S=line.split("\\s+");
			Student student=new Student(S[0],S[1],S[2]);
			listStu.add(student);
		}
		for(int i=0;i<listStu.size()-1;i++) {
			for(int j=0;j<listStu.size()-i-1;j++) {
				Student student1=listStu.get(j);
				Student student2=listStu.get(j+1);
				double grade1=Double.parseDouble(student1.getGrade());
				double grade2=Double.parseDouble(student2.getGrade());
				if(grade1<grade2) {
					listStu.set(j, student2);
					listStu.set(j+1, student1);
				}
			}
		}
		System.out.println("����\t����\t�ɼ�\t����ʱ��");
		for(int i=0;i<listStu.size();i++) {
			System.out.println(i+1+"\t"+listStu.get(i).toString());
		}
	}
}
