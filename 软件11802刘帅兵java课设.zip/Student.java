package ninth;

public class Student {
	private String name;
	private String grade;
	private String time;
	public Student(String name, String grade, String time) {
		super();
		this.name = name;
		this.grade = grade;
		this.time = time;
	}
	public Student() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return name+"\t"+grade+"\t"+time;
	}
	
}
